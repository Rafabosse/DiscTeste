package br.entidades;

public class Calculator {
	
	public int add(int num1, int num2) {
		return num1 + num2;
    }	
}
