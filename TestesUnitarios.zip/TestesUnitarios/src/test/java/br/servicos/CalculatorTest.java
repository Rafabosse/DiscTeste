package br.servicos;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorTest {

	@Test
	public void testAdd() {

		//cenario
		
		//acao
		
		//verificacao
		
	}
}
